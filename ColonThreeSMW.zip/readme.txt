ColonThree: Created by HoorayForJay and ShadowDragon121.
TAS video: https://www.youtube.com/watch?v=7BDdhFNnSkQ
Completion of ColonThree requires not only clearing "The Level",
but also defeating the boss ColonThree afterwards.